package controle;

import java.util.ArrayList;
import modelo.FilmeVO;
import modelo.FilmeModelo;

public class FilmeControle {
	
	FilmeModelo m;
	
	public FilmeControle() {
		m = new FilmeModelo();
	}

	public void carga() {
		m.carga();
	}
	
	public FilmeVO obterFilme(String op) {
		FilmeVO f = m.obterFilme(op);
		return f;
	}
	
	public boolean procurar(int op) {
		boolean f = m.procura(op);
		return f;
	}
	
	public void adicionar(FilmeVO f) {
		m.adicionar(f);
	}

	public void remover(FilmeVO f) {
		m.remover(f);
	}

	
	
	public ArrayList<FilmeVO> getLista() {
		ArrayList<FilmeVO> copiaLista = m.getFilmes();
		
		return copiaLista;
	}

	public boolean pesquisar(String op) {
		boolean f = m.pesquisar(op);
		return f;
	}

	public String peganome(int option) {
		String f = m.peganome(option);
		return f;
	}
	public String pegaempresa(int option) {
		String f = m.pegaempresa(option);
		return f;
	}
	public String pegagenero(int option) {
		String f = m.pegagenero(option);
		return f;
	}
	public int pegacodigo(int option) {
		int f = m.pegacodigo(option);
		return f;
	}
	
	public boolean setar(String novonome, String novogenero, String novoempresa, int option) {
		boolean f = m.setar( novonome,  novogenero,  novoempresa,  option);
		return f;
	}

	public int pegapornome(String op) {
		int f = m.pegapornome(op);
		return f;
	}

	public boolean checadisponivel(int option) {
		boolean f = m.disponi(option);
		return f;
	}

	public boolean setDisponi(int cod, boolean disp) {
		boolean tt = m.setDisponi(cod, disp);
		return tt;
		
	}

	public boolean getDisp(int cont) {
		boolean tt = m.getDisponi(cont);
		return tt;
	}
}
