package modelo;


public class FilmeVO {
	public String nome;
	public String empresa;
	public String genero;
	public int codigo;
	public boolean disponivel;
	
	public FilmeVO(String nome, String empresa, String genero, int codigo, boolean disponivel) {
		super();
		this.nome = nome;
		this.empresa = empresa;
		this.genero = genero;
		this.codigo = codigo;
		this.disponivel = disponivel;
	}
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String muda) {
		this.genero = muda;
	}

	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public boolean getDisponivel() {
		return disponivel;
	}
	
	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}
	
}
