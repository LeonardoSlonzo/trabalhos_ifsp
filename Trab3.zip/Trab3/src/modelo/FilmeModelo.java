package modelo;

import java.util.ArrayList;

public class FilmeModelo {
	
	private ArrayList<FilmeVO> filmeLista;
	
	public FilmeModelo() {
		
		filmeLista = new ArrayList<FilmeVO>(); 
	}
	
	public void carga(){
		int codd = filmeLista.size();
		FilmeVO filme1 = new FilmeVO("mineirinho ultra adventure", "aquela la mesmo", "suspense", codd++, true);
		FilmeVO filme2 = new FilmeVO("porradaria 2: pagode of the night", "esqueci o nome", "muita porradaria ao som de pagode.mp3", codd++,true );
		FilmeVO filme3 = new FilmeVO("eae marquim dj", "faz o sampley de guitarra", "ta na nu na nu naa", codd++, true);
		FilmeVO filme4 = new FilmeVO("corrida de animais silvestres 3d", "jorge's industries", "da 10 professor", codd++, true);
		FilmeVO filme5 = new FilmeVO("lapadins, os banan�es", "pip n � suporte", "main maeve nem � gente", codd++, true);
		
		filmeLista.add(filme1);
		filmeLista.add(filme2);
		filmeLista.add(filme3);
		filmeLista.add(filme4);
		filmeLista.add(filme5);
	}
	
	public FilmeVO obterFilme(String op) {
		for(FilmeVO f : filmeLista) {
			if(f.getNome().equals(op)) {
				return f;
			}
		}
		
		return null;
	}
	
	public Boolean procura(int op) {

		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == op) {
				return true;
			}
		}
		return false;
	}
	
	public ArrayList<FilmeVO> getFilmes() {
		return filmeLista;
	}
	
	public void adicionar(FilmeVO f) {
		filmeLista.add(f);
	}

	public void remover(FilmeVO f) {
		filmeLista.remove(f);
	}

	public boolean pesquisar(String op) {
		for(FilmeVO f : filmeLista) {
			if(f.getNome().equals(op)) {
				
				return true;
			}
			
		}
		
		return false;
	}
	
	public String peganome(int option) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == option) {
				return f.getNome();
			}
		}
		return null;
	}
	public String pegaempresa(int option) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == option) {
				return f.getEmpresa();
			}
		}
		return null;
	}
	public String pegagenero(int option) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == option) {
				return f.getGenero();
			}
		}
		return null;
	}
	public int pegapornome(String option) {
		for(FilmeVO f : filmeLista) {
			if(f.getNome().equals(option)) {
				return f.getCodigo();
			}
		}
		return -5;
	}
	public int pegacodigo(int option) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == option) {
				return f.getCodigo();
			}
		}
		return -1;
	}
	public boolean setar(String novonome, String novogenero, String novoempresa, int option) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == option) {
				f.setEmpresa(novoempresa);
				f.setNome(novonome);
				f.setGenero(novogenero);
				return true;
			}
		}
		return false;
	}

	public boolean disponi(int option) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == option) {
				if(f.getDisponivel() == true)
				return true;
			}
		}
		return false;
	}

	public boolean setDisponi(int cod, boolean disp) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == cod) {
				f.setDisponivel(disp);
				return true;
			}
		}
		return false;
	}

	public boolean getDisponi(int cont) {
		for(FilmeVO f : filmeLista) {
			if(f.getCodigo() == cont) {
				if(f.getDisponivel() == true) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}
}
