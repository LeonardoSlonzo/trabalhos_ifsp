package visao;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controle.FilmeControle;

public class FilmeAlugar extends JFrame{
	private FilmeControle c;
	private JTextField tnome;
	private JTextField tempresa;
	private JTextField tgenero;
	private JTextField tcod;
	private JTextField tdisp;
	private JButton bfechar;
	private JButton balugar;
	private JButton bdevolver;
	private JButton blistar;
	private Properties prop;
	private FilmeListar list;	

	public FilmeAlugar(FilmeControle c) {
		this.c = c;
		list = new FilmeListar(c);
	}

	public int option;
	public void alugar(Properties prop) {
		this.prop = prop;
		String op = JOptionPane.showInputDialog(this, prop.getProperty("remov.cod"));
		if(op != null) {

			boolean ehNumero; 
			try {									//Verifica se � n�mero
				option = Integer.parseInt(op);
				ehNumero = true;
			} catch (NumberFormatException e) {	  
				ehNumero = false;
			}
			if(ehNumero) {

				boolean verifica = c.procurar(option);
				if(verifica == true) {
					this.setVisible(true);
					setLayout( new FlowLayout());
					
					tdisp = new JTextField(10);

					boolean disponi = c.checadisponivel(option);
					if(disponi == true) {
						tdisp.setText(prop.getProperty("disponivel"));
					} else {
						tdisp.setText(prop.getProperty("alugado"));
					}
					ButtonHandler handler = new ButtonHandler();

					JLabel lcod = new JLabel(prop.getProperty("remov.cod"));
					JLabel lnome = new JLabel(prop.getProperty("list.name"));
					JLabel lempresa = new JLabel(prop.getProperty("list.comp"));
					JLabel lgenero = new JLabel(prop.getProperty("list.genr"));
					JLabel ldisp = new JLabel(prop.getProperty("disp"));

					tcod = new JTextField(5);
					tnome = new JTextField(30);
					tempresa = new JTextField(30);
					tgenero = new JTextField(30);
					bfechar = new JButton(prop.getProperty("menu.fecha"));
					balugar = new JButton(prop.getProperty("alug"));
					bdevolver = new JButton(prop.getProperty("devolv"));
					blistar = new JButton(prop.getProperty("menu.list"));

					tnome.setText(c.peganome(option));
					tempresa.setText(c.pegaempresa(option));
					tgenero.setText(c.pegagenero(option));
					tcod.setText(Integer.toString(c.pegacodigo(option)));

					tcod.setEditable(false);
					tnome.setEditable(false);
					tempresa.setEditable(false);
					tgenero.setEditable(false);
					tdisp.setEditable(false);

					add(lnome);		add(tnome);
					add(lempresa);	add(tempresa);
					add(lgenero);	add(tgenero);
					add(lcod);		add(tcod);
					add(ldisp);		add(tdisp);
					add(balugar);	add(bdevolver);
					add(blistar);	add(bfechar);
					bfechar.addActionListener(handler);
					balugar.addActionListener(handler);
					bdevolver.addActionListener(handler);
					blistar.addActionListener(handler);
				}else {
					JOptionPane.showMessageDialog(null, prop.getProperty("alt.error"));
				}
			} else {
				JOptionPane.showMessageDialog(null, prop.getProperty("alt.soment"));
			}
		}
	}
	//handler
	public class ButtonHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event) {

			if(event.getSource() == balugar) {
				int cod = Integer.parseInt(tcod.getText());
				boolean tt = c.setDisponi(cod, false);

				if(tt == true) {
					tdisp.setText(prop.getProperty("alugado"));
					JOptionPane.showMessageDialog(null, prop.getProperty("concl"));
				}
			} else if(event.getSource() == bdevolver) {
				int cod = Integer.parseInt(tcod.getText());
				boolean tt = c.setDisponi(cod, true);

				if(tt == true) {
					tdisp.setText(prop.getProperty("disponivel"));
					JOptionPane.showMessageDialog(null, prop.getProperty("concl"));
				}
			} else if(event.getSource() == blistar ) {

				list.setSize(958,330);
				list.setDefaultCloseOperation(list.DISPOSE_ON_CLOSE);
				list.setLocationRelativeTo(blistar);
				list.setResizable(true); 
				list.setTitle(prop.getProperty("menu.list"));
				list.setVisible(true);
				list.setLayout(new FlowLayout());
				list.listar(prop);

			} else {
				FilmeAlugar.this.dispose();
			}
		}
	}

}