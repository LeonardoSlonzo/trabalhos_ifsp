package visao;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import controle.FilmeControle;
import modelo.FilmeVO;

public class FilmeListar extends JFrame {
	
	private JTextArea talist1;
	private JTextArea talist2;
	private JTextArea talist3;
	private JTextArea talist4;
	
	private JButton blistlimpa;
	private JButton blistfecha;
	private JButton blistlista;

	private ArrayList<FilmeVO> filmeLista;
	private FilmeControle c;
	
	private class ButtonHandler implements ActionListener {

		public void actionPerformed( ActionEvent event )
		{

			if(event.getSource() == blistlista) {
				FilmeListar.this.blistar();
			} else if(event.getSource() == blistlimpa) {
				FilmeListar.this.blimpar();
			} else if(event.getSource() == blistfecha) {
				FilmeListar.this.dispose();
			}
		}
	}
	public FilmeListar(FilmeControle c) {
		this.c = c;
	}
	private Properties propl;
	//private JScrollPane rolagem1;
	public void listar(Properties prop) {
		this.propl = prop;
		
		ButtonHandler handler = new ButtonHandler();
		setLayout( new FlowLayout());
		talist1 = new JTextArea("",15,25);
		talist1.setEditable(false);
		talist2 = new JTextArea("",15,25);
		talist2.setEditable(false);
		talist3 = new JTextArea("",15,25);
		talist3.setEditable(false);
		talist4 = new JTextArea("",15,8);
		talist4.setEditable(false);
		//rolagem1 = new JScrollPane();
		//rolagem = new JScrollPane( talist2 );
		
		blistlimpa = new JButton(prop.getProperty("clean"));
		blistfecha = new JButton(prop.getProperty("menu.fecha"));
		blistlista = new JButton(prop.getProperty("menu.list"));

		//this.getContentPane().add(rolagem1);

		add(talist1);
		add(talist2);
		add(talist3);
		add(talist4);
		add(blistlista);
		add(blistlimpa); 
		add(blistfecha);
		
		
		blistlista.addActionListener(handler);
		blistlimpa.addActionListener(handler);
		blistfecha.addActionListener(handler);
		
		return;
	}
	private void blistar() {
		String strNome = "";
		String strGener = "";
		String strEmpre = "";
		String strDisp = "";
		
		filmeLista = c.getLista();
		if(filmeLista.isEmpty()) {
			JOptionPane.showMessageDialog( 
					this, propl.getProperty("list.empty"));
			return;
		} 
		strNome = strNome.concat(String.format(propl.getProperty("list.name")));
		strEmpre = strEmpre.concat(String.format(propl.getProperty("list.comp")));
		strGener = strGener.concat(String.format(propl.getProperty("list.genr")));
		strDisp = strDisp.concat(String.format(propl.getProperty("list.disp")));
		
		int cont = 0;
		String s = propl.getProperty("s");
		String n = propl.getProperty("n");
		
		for(FilmeVO b: filmeLista) {
			boolean tt = c.getDisp(cont);
			strNome = strNome.concat(String.format("\n%d.  %s", b.getCodigo(),  b.getNome()));
			strEmpre = strEmpre.concat(String.format("\n%d.  %s", b.getCodigo(),  b.getEmpresa()));
			strGener = strGener.concat(String.format("\n%d.  %s", b.getCodigo(), b.getGenero()));
			if(tt == true) {
				strDisp = strDisp.concat(String.format("\n%d.  %s", b.getCodigo(), s ));
			} else {
				strDisp = strDisp.concat(String.format("\n%d.  %s", b.getCodigo(), n ));
			}
			cont++;
		} 
		talist1.setText(strNome);
		talist2.setText(strEmpre);
		talist3.setText(strGener);
		talist4.setText(strDisp);
	}
	private void blimpar() {
		talist1.setText("");
		talist2.setText("");
		talist3.setText("");
		talist4.setText("");
	} 
}
