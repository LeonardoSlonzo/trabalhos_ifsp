package visao;

import java.util.Properties;
import java.util.Scanner;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

import controle.FilmeControle;


public class FilmeVisaoMenu extends JFrame { //	menu mostro 
	private Properties prop;
	private FilmeControle c;
	Scanner tec;
	public int x = 0;
	
	private JLabel lmenu;
	private JLabel lop;
	
	private JButton badd;
	private JButton blist;
	private JButton bremov;
	private JButton bfecha;
	private JButton bcarga;
	private JButton baltera;
	private JButton bpesqui;
	private JButton bmudaidioma;
	private JButton baluga;
	public int cod = 0;
	
	
	public FilmeVisaoMenu() {
		super("Menu");
		c = new FilmeControle();
	}
	public class ButtonHandler implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent event) {
			
			FilmeAdicionar fm = new FilmeAdicionar(c);
			FilmeListar fl = new FilmeListar(c);
			FilmeRemover fr = new FilmeRemover(c);
			FilmeAlterar fa = new FilmeAlterar(c);
			FilmeProcurar fp = new FilmeProcurar(c);
			FilmeVisao v = new FilmeVisao(c);
			FilmeAlugar fg = new FilmeAlugar(c);
			
			if(event.getSource() == badd) {  //Op��o Adicionar
				fm.setSize(378, 205);
				fm.setDefaultCloseOperation(fm.DISPOSE_ON_CLOSE);
				fm.setLocationRelativeTo(null);
				fm.setResizable(false); 
				fm.setTitle(prop.getProperty("menu.add"));
				fm.setVisible(true);
				fm.setLayout(new FlowLayout());
				fm.adicionar(prop);
				
			} else if(event.getSource() == blist) { //Op��o Listar
		
				fl.setSize(958,330);
				fl.setDefaultCloseOperation(fl.DISPOSE_ON_CLOSE);
				fl.setLocationRelativeTo(null);
				fl.setResizable(true); 
				fl.setTitle(prop.getProperty("menu.list"));
				fl.setVisible(true);
				fl.setLayout(new FlowLayout());
				fl.listar(prop);
			
			}else if(event.getSource() == bremov) {	 //Op��o Remover
				fr.setSize(270, 100);
				fr.setDefaultCloseOperation(fm.DISPOSE_ON_CLOSE);
				fr.setLocationRelativeTo(null);
				fr.setResizable(false); 
				fr.setTitle(prop.getProperty("menu.remov"));
				fr.setVisible(true);
				fr.setLayout(new FlowLayout());
				fr.remover(prop);	
			
			} else if(event.getSource() == baltera) {  //Op��o Altera
				fa.setSize(378, 200);
				fa.setDefaultCloseOperation(fa.DISPOSE_ON_CLOSE);
				fa.setLocationRelativeTo(null);
				fa.setResizable(false); 
				fa.setTitle(prop.getProperty("menu.altera"));
				fa.setVisible(false);
				fa.setLayout(new FlowLayout());
				fa.alterar(prop);	
				
			
			} else if(event.getSource() == bcarga) { //Op��o Carga
				JOptionPane.showMessageDialog(FilmeVisaoMenu.this, prop.getProperty("carga"));
				c.carga();
				cod += 5;
				
			} else if(event.getSource() == bpesqui){ //Op��o Procurar
				fp.setSize(357, 225);
				fp.setDefaultCloseOperation(fp.DISPOSE_ON_CLOSE);
				fp.setLocationRelativeTo(null);
				fp.setResizable(false); 
				fp.setTitle(prop.getProperty("menu.pesqui"));
				fp.setVisible(false);
				fp.setLayout(new FlowLayout());
				fp.procurar(prop);	
			}else if(event.getSource() == bmudaidioma) { //Op��o Mudar Idioma
				
				FilmeVisaoMenu.this.dispose();
				v.setSize( 220, 130 );
				v.setResizable(true);
				v.setDefaultCloseOperation(v.DISPOSE_ON_CLOSE);
				v.setLocationRelativeTo(null);
				v.setResizable(false); 
				v.setVisible(true);
				
				
			} else if(event.getSource() == baluga) { //Op��p Alugar
				fg.setSize(360, 250);
				fg.setDefaultCloseOperation(fg.DISPOSE_ON_CLOSE);
				fg.setLocationRelativeTo(null);
				fg.setResizable(false); 
				fg.setTitle(prop.getProperty("alug"));
				fg.setVisible(false);
				fg.setLayout(new FlowLayout());
				fg.alugar(prop);
			} else { // Fechar
				int tt =JOptionPane.showConfirmDialog(
						FilmeVisaoMenu.this, prop.getProperty("fecha.conf"),
						prop.getProperty("fecha.titu"), JOptionPane.YES_NO_OPTION);
				if(tt == 0) {
					System.exit(0);
				}
			}
		}
	}
	public void opcao(Properties prop, FilmeControle c) {
		this.c = c;
		this.prop = prop;
		ButtonHandler handler = new ButtonHandler();
		JFrame f = new JFrame();
		
			f.setSize(230, 210);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.setLocationRelativeTo(null);
			f.setResizable(false); 
			f.setTitle("Menu");
			f.setVisible(true);
			f.setLayout(new FlowLayout());
			
			lmenu = new JLabel(prop.getProperty("menu.welcome"));
			lop = new JLabel(prop.getProperty("menu.op"));
			badd = new JButton(prop.getProperty("menu.add"));
			badd.addActionListener(handler);
			blist = new JButton(prop.getProperty("menu.list"));
			blist.addActionListener(handler);
			bremov = new JButton(prop.getProperty("menu.remov"));
			bremov.addActionListener(handler);
			bcarga = new JButton(prop.getProperty("menu.carga"));
			bcarga.addActionListener(handler);
			bfecha = new JButton(prop.getProperty("menu.fecha"));
			bfecha.addActionListener(handler);
			baltera = new JButton(prop.getProperty("menu.altera"));	
			baltera.addActionListener(handler);
			bpesqui = new JButton(prop.getProperty("menu.pesqui"));
			bpesqui.addActionListener(handler);
			bmudaidioma = new JButton(prop.getProperty("idioma"));
			bmudaidioma.addActionListener(handler);
			baluga = new JButton(prop.getProperty("alug"));
			baluga.addActionListener(handler);
			
			f.add(lmenu);
			f.add(lop);
			f.add(badd);
			f.add(blist);
			f.add(bremov);
			f.add(baltera);
			f.add(bpesqui);
			f.add(baluga);
			f.add(bmudaidioma);
			f.add(bfecha);
			f.add(bcarga);
	}
}
