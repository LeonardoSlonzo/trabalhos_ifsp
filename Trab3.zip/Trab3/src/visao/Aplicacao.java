package visao;
/**
 * Trabalho LPA PT 3
 * Leonardo e Nathanael
 * ht171077x  a161116x 
**/
import javax.swing.JFrame;

import controle.FilmeControle;
public class Aplicacao {
	
	public static void main(String[]args) {
		FilmeControle c = new FilmeControle();
		FilmeVisao v = new FilmeVisao(c);
		v.setSize( 220, 130 );
		v.setResizable(true);
		v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		v.setLocationRelativeTo(null);
		v.setResizable(false); 
		v.setVisible(true);
	} 
}