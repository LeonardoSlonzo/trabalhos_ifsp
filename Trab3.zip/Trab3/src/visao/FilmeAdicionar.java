package visao;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Closeable;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controle.FilmeControle;
import modelo.FilmeVO;

public class FilmeAdicionar extends JFrame {
	private FilmeControle c;
	
	public FilmeAdicionar(FilmeControle c) {
		this.c = c;
	}
	private class ButtonHandler implements ActionListener {
		
		public void actionPerformed( ActionEvent event )
		{
			
			if(event.getSource() == adici) {
				FilmeVO f1 = c.obterFilme(tnome.getText().toLowerCase());
				if(f1 == null) {
					if(tnome.getText().equals("") || tnome.getText().equals(null)) {
					
					} else {
						int codigo = c.getLista().size();
						String nome = tnome.getText().toLowerCase();
						String empresa = tempre.getText().toLowerCase();
						String genero = tgener.getText().toLowerCase();
						FilmeVO f = new FilmeVO(nome, empresa, genero, codigo++, true);

						c.adicionar(f);
						JOptionPane.showMessageDialog(null, prop.getProperty("add.concl"), null, 1);
						tempre.setText(null);
						tnome.setText(null);
						tgener.setText(null);
						FilmeAdicionar.this.dispose();
					}
				} else {
					JOptionPane.showMessageDialog(null, prop.getProperty("add.error"), "Error", 1);
				}
				tnome.requestFocus();
			} else if(event.getSource() == fecha) {
				FilmeAdicionar.this.dispose();
			}
		}
		
	}
	
	private JTextField tnome;
	private JTextField tempre;
	private JTextField tgener;
	private JButton adici;
	private JButton fecha;

	private Properties prop;
	
	public void adicionar(Properties prop) {
		this.prop = prop;
		
		ButtonHandler handler = new ButtonHandler();
		JLabel lnome = new JLabel(prop.getProperty("add.name"));
		JLabel lempre = new JLabel(prop.getProperty("add.comp")); 
		JLabel lgener = new JLabel(prop.getProperty("add.genr"));
		
		adici = new JButton(prop.getProperty("add.but"));
		fecha = new JButton(prop.getProperty("menu.fecha"));
		tnome = new JTextField(30);
		tempre = new JTextField(30);
		tgener = new JTextField(30);
		
		add(lnome);  	add(tnome);
		add(lempre); 	add(tempre);
		add(lgener); 	add(tgener);
		add(adici);		add(fecha);
		
		adici.addActionListener(handler);
		fecha.addActionListener(handler);
	}
}
