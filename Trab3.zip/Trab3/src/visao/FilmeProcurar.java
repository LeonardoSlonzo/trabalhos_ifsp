package visao;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controle.FilmeControle;

public class FilmeProcurar extends JFrame {
	private FilmeControle c;

	private JTextField tnome;
	private JTextField tempresa;
	private JTextField tgenero;
	private JTextField tcod;
	private JTextField tdisp;
	private JButton bfechar;

	public FilmeProcurar(FilmeControle c) {
		this.c = c;
	}

	public void procurar(Properties prop) {

		String op = JOptionPane.showInputDialog(this, prop.getProperty("list.name"));
		if(op != null) {

			boolean verifica = c.pesquisar(op.toLowerCase());
			if(verifica == true) {
				ButtonHandler handler = new ButtonHandler();
				this.setVisible(true);
				setLayout( new FlowLayout());
				tdisp = new JTextField(12);

				JLabel lcod = new JLabel(prop.getProperty("remov.cod"));
				JLabel lnome = new JLabel(prop.getProperty("list.name"));
				JLabel lempresa = new JLabel(prop.getProperty("list.comp"));
				JLabel lgenero = new JLabel(prop.getProperty("list.genr"));
				JLabel ldisp = new JLabel(prop.getProperty("disp"));

				tcod = new JTextField(5);
				tnome = new JTextField(30);
				tempresa = new JTextField(30);
				tgenero = new JTextField(30);
				bfechar = new JButton(prop.getProperty("menu.fecha"));

				int option = c.pegapornome(op);
				boolean disponi = c.checadisponivel(option);
				if(disponi == true) {
					tdisp.setText(prop.getProperty("disponivel"));
				} else {
					tdisp.setText(prop.getProperty("alugado"));
				}

				tnome.setText(c.peganome(option));
				tempresa.setText(c.pegaempresa(option));
				tgenero.setText(c.pegagenero(option));
				tcod.setText(Integer.toString(c.pegacodigo(option)));

				tcod.setEditable(false);
				tnome.setEditable(false);
				tempresa.setEditable(false);
				tgenero.setEditable(false);
				tdisp.setEditable(false);

				add(lnome);		add(tnome);
				add(lempresa);	add(tempresa);
				add(lgenero);	add(tgenero);
				add(lcod);		add(tcod);
				add(ldisp);		add(tdisp);
				add(bfechar);
				bfechar.addActionListener(handler);
			}else {
				JOptionPane.showMessageDialog(null, prop.getProperty("alt.error"));
			}
		}
	}
	public class ButtonHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == bfechar) {
				FilmeProcurar.this.dispose();
			}
		}
	}
}
