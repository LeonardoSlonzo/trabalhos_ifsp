package visao;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

import controle.FilmeControle;
import modelo.FilmeVO;

public class FilmeAlterar extends JFrame{
	
	private FilmeControle c;
	
	public Properties prop3;
	private ArrayList<FilmeVO> filmeLista;
	private JTextField tnome;
	private JTextField tempresa;
	private JTextField tgenero;
	private JTextField tcod;
	private JButton bfechar;
	private JButton balterar;
	
	public class ButtonHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == balterar) {
				altera();
			} else {
				FilmeAlterar.this.dispose();
			}
		}
		
	}
	
	
	public FilmeAlterar(FilmeControle c) {

		this.c = c;
	}
	private int option = 0;
	public void alterar(Properties prop) {
		this.prop3 = prop;
		String op = JOptionPane.showInputDialog(this, prop3.getProperty("remov.cod"),prop3.getProperty("alt.soment"));
		
		if(op != null) {
			boolean ehNumero; 
			try {									//Verifica se � n�mero
				option = Integer.parseInt(op);
				ehNumero = true;
			} catch (NumberFormatException e) {	  
				ehNumero = false;
			}
			if(ehNumero == true) {
				boolean verifica = c.procurar(option);
				if(verifica == true) {
					ButtonHandler handler = new ButtonHandler();
					this.setVisible(true);
					setLayout( new FlowLayout());
					JLabel lcod = new JLabel(prop3.getProperty("remov.cod"));
					JLabel lnome = new JLabel(prop3.getProperty("list.name"));
					JLabel lempresa = new JLabel(prop3.getProperty("list.comp"));
					JLabel lgenero = new JLabel(prop3.getProperty("list.genr"));
					tcod = new JTextField(5);
					//tcod.setEnabled(false);
					tnome = new JTextField(30);
					tempresa = new JTextField(30);
					tgenero = new JTextField(30);
					
					bfechar = new JButton(prop3.getProperty("menu.fecha"));
					
					tnome.setText(c.peganome(option).toLowerCase());
					tempresa.setText(c.pegaempresa(option).toLowerCase());
					tgenero.setText(c.pegagenero(option).toLowerCase());
					tcod.setText(Integer.toString(c.pegacodigo(option)));
					tcod.setEditable(false);
					
					balterar = new JButton(prop3.getProperty("menu.altera"));
					
					add(lnome);		add(tnome);
					add(lempresa);	add(tempresa);
					add(lgenero);	add(tgenero);
					add(lcod);		add(tcod);
					add(balterar);	add(bfechar);
					
					balterar.addActionListener(handler);
					bfechar.addActionListener(handler);	
				}else {
					JOptionPane.showMessageDialog(null, prop3.getProperty("alt.error"));
				}
			} else {
				JOptionPane.showMessageDialog(null,prop3.getProperty("alt.soment"));
			}
		}
	}
	public void altera() {
		String novonome = tnome.getText().toLowerCase();
		String novogenero = tgenero.getText().toLowerCase();
		String novoempresa = tempresa.getText().toLowerCase();
		boolean b = c.setar(novonome, novogenero, novoempresa, option);
		if(b == true) {
			JOptionPane.showMessageDialog(null,prop3.getProperty("alt.concl"));
			tnome.requestFocus();
		}
	}
}
