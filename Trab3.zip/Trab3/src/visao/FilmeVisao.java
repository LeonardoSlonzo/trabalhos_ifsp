package visao;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.FileInputStream;
import java.io.IOException;

import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import controle.FilmeControle;

public class FilmeVisao extends JFrame{ // menu nao tao monstro
	
	FilmeControle c;
	private Properties prop;
	private JButton BlingPort;
	private JButton BlingEng;
	private JButton BlingEsp;
	private JLabel Lling;
	
	public FilmeVisao(FilmeControle c) {
		super("Select: ");
		this.c = c;
		prop = new Properties();
		msgLeng();
		
	}
	
	public class ButtonHandler implements ActionListener{
			
		public void actionPerformed(ActionEvent event) {
			FilmeVisaoMenu fvm = new FilmeVisaoMenu();
			
			FileInputStream arq;
			
			if(event.getSource() == BlingPort || event.getSource() == BlingEng || event.getSource() == BlingEsp) {
				
				try{
					fvm.dispose();
					if(event.getSource() == BlingPort) {

						arq = new FileInputStream("propriedades/msg_port.properties");

						prop.load(arq);
						fvm.opcao(prop, c);
						
						FilmeVisao.this.dispose();

					}
					else if(event.getSource() == BlingEng) {
						arq = new FileInputStream("propriedades/msg_eng.properties");

						prop.load(arq);
						fvm.opcao(prop,c );
						FilmeVisao.this.dispose();
					}
					else if(event.getSource() == BlingEsp) {
						arq = new FileInputStream("propriedades/msg_esp.properties");
						prop.load(arq);
						fvm.opcao(prop,c );
						FilmeVisao.this.dispose();
					}
				}catch(IOException e){
					e.printStackTrace();
					System.out.print("Error, properties not found or corrupted");
					System.exit(0);
				}
			}
		}
	}
	
		public void msgLeng(){
		
		
		setLayout(new FlowLayout());
		ButtonHandler handler = new ButtonHandler();
		
		Lling = new JLabel("Chosse the lenguage: ");
		BlingPort = new JButton("Portugu�s");
		BlingPort.addActionListener(handler);
		BlingEng = new JButton("English");
		BlingEng.addActionListener(handler);
		BlingEsp = new JButton("Espa�ol");
		BlingEsp.addActionListener(handler);
		add(Lling); 
		add(BlingPort); 
		add(BlingEng); 
		add(BlingEsp);
	}
}
