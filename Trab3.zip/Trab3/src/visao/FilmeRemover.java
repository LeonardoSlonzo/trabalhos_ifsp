package visao;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controle.FilmeControle;
import modelo.FilmeVO;
public class FilmeRemover extends JFrame {
	
	private ArrayList<FilmeVO> filmeLista;
	private Properties prop2;
	private FilmeControle c;
	private FilmeListar list;
	
	public FilmeRemover(FilmeControle c) {
		this.c = c;
		list = new FilmeListar(c);
	}
	
	public class ButtonHandler implements ActionListener{
		
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == bremover) {
				remove();
				
			} else if(event.getSource() == blistar) {
				list.setSize(958,330);
				list.setDefaultCloseOperation(list.DISPOSE_ON_CLOSE);
				list.setLocationRelativeTo(blistar);
				list.setResizable(true); 
				list.setTitle(prop2.getProperty("menu.list"));
				list.setVisible(true);
				list.setLayout(new FlowLayout());
				list.listar(prop2);
				
			} else {
				FilmeRemover.this.dispose();
			}
			
		}
		
	}
	private JButton bfechar;
	private JButton blistar;
	private JButton bremover;
	private JTextField tentrada;
	
	public void remover(Properties prop) { //menu do remover
		this.prop2 = prop;
		ButtonHandler handler = new ButtonHandler();
		setLayout( new FlowLayout());
		
		JLabel lcod = new JLabel(prop2.getProperty("remov.cod"));
		bfechar = new JButton(prop2.getProperty("menu.fecha"));
		blistar = new JButton(prop2.getProperty("menu.list"));
		bremover = new JButton(prop2.getProperty("menu.remov"));
		tentrada = new JTextField(15);
		
		add(lcod);
		add(tentrada);
		add(bremover);
		add(blistar);
		add(bfechar);
		
		bremover.addActionListener(handler);
		blistar.addActionListener(handler);
		bfechar.addActionListener(handler);
	}
	public void remove() { // remover filme
		filmeLista = c.getLista();
		

		if(!filmeLista.isEmpty()) {
			
			int test = 0;
			int codi = Integer.parseInt(tentrada.getText());
			for(FilmeVO b: filmeLista) {
				if(codi == b.getCodigo()) {
					c.remover(b);
					JOptionPane.showMessageDialog(null,prop2.getProperty("remov.concl"));
					test++;
					tentrada.setText("");
					tentrada.requestFocus();
					break;
				}
			} 
			if(test == 0)
				JOptionPane.showMessageDialog(null,prop2.getProperty("alt.error"));
		} else {
			JOptionPane.showMessageDialog(
					null, prop2.getProperty("list.empty"));
		}
	}
}